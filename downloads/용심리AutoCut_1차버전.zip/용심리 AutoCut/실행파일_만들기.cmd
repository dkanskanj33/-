@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" goto missing
.venv\Scripts\python.exe -m pip install "pyinstaller>=6.16,<7"
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --windowed --onedir --name YongsimriAutoCut --collect-all imageio_ffmpeg run_app.py
if errorlevel 1 goto failed
copy /y "시작_여기부터.md" "dist\YongsimriAutoCut\시작_여기부터.md" >nul
copy /y "THIRD_PARTY_NOTICES.md" "dist\YongsimriAutoCut\THIRD_PARTY_NOTICES.md" >nul
echo 완료: dist\YongsimriAutoCut 폴더 전체를 보관하세요.
echo 그 안의 YongsimriAutoCut.exe를 더블클릭하면 됩니다.
pause
exit /b 0
:missing
echo 먼저 초기설치.cmd를 실행하세요.
pause
exit /b 1
:failed
echo 실행 파일을 만들지 못했습니다. 위 오류 내용을 확인하세요.
pause
exit /b 1
