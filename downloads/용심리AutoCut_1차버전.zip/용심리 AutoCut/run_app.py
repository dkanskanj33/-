from yongsimri_autocut.app import main

if __name__ == "__main__":
    main()
