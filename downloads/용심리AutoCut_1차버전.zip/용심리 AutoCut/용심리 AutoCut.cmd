@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" goto missing
.venv\Scripts\python.exe -m yongsimri_autocut
if errorlevel 1 goto failed
exit /b 0
:missing
echo 먼저 [초기설치.cmd]를 실행하세요.
pause
exit /b 1
:failed
echo 프로그램을 실행하지 못했습니다. 위 오류 내용을 확인하세요.
pause
exit /b 1
