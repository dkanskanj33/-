"""Conservative, fully local first-pass video editing. No speech recognition.

All public times are presentation seconds from the beginning of the media.
FFmpeg processes are invoked with argument lists; file names never enter a shell.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from fractions import Fraction
from pathlib import Path
from typing import Callable
import hashlib
import json
import math
import os
import queue
import re
import shutil
import subprocess
import tempfile
import threading
import time
import uuid

import numpy as np

Progress = Callable[[float, str], None]
CancelCheck = Callable[[], bool]


class MediaError(RuntimeError):
    pass


class Cancelled(MediaError):
    pass


@dataclass
class Settings:
    min_silence: float = 2.5
    keep_silence: float = 1.0
    threshold_db: float = -48.0
    guard: float = 0.25

    def validate(self):
        if not all(math.isfinite(float(x)) for x in asdict(self).values()):
            raise MediaError("설정값은 유한한 숫자여야 합니다.")
        if not (0.5 <= self.min_silence <= 120):
            raise MediaError("긴 무음 기준은 0.5~120초로 설정해 주세요.")
        if not (0.2 <= self.keep_silence < self.min_silence):
            raise MediaError("남길 쉼은 0.2초 이상이며 긴 무음 기준보다 짧아야 합니다.")
        if not (-90 <= self.threshold_db <= -25):
            raise MediaError("무음 감도는 -90~-25 dB 범위여야 합니다.")
        if not (0.1 <= self.guard <= 2) or self.keep_silence < 2 * self.guard:
            raise MediaError("남길 쉼은 음절 보호 여백의 두 배 이상이어야 합니다.")
        return self


@dataclass
class MediaInfo:
    path: Path
    duration: float
    width: int
    height: int
    fps: float
    has_audio: bool
    audio_channels: int = 0
    audio_sample_rate: int = 0
    video_codec: str = ""
    audio_codec: str = ""


@dataclass
class Cut:
    id: str
    start: float
    end: float
    kind: str = "silence"
    reason: str = ""
    enabled: bool = True


@dataclass
class Analysis:
    info: MediaInfo
    cuts: list[Cut]
    settings: Settings
    silences: list[tuple[float, float]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def ffmpeg_exe() -> str:
    override = os.environ.get("IMAGEIO_FFMPEG_EXE") or os.environ.get("AUTOCUT_FFMPEG")
    if override:
        return override
    # A packaged Windows installation includes the binary supplied by imageio-ffmpeg.
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except (ImportError, RuntimeError):
        executable = shutil.which("ffmpeg")
        if executable:
            return executable
        raise MediaError("FFmpeg를 찾지 못했습니다. 초기설치.cmd를 실행해 주세요.")


def _kwargs():
    return {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}


def _check_cancel(cancelled):
    if cancelled and cancelled():
        raise Cancelled("작업을 취소했습니다.")


def _notify(progress, percent, message):
    if progress:
        progress(max(0.0, min(100.0, float(percent))), message)


def _run(args, *, cancelled=None, progress=None, duration=None, cwd=None):
    """Drain both pipes concurrently, report progress, and terminate on cancellation."""
    _check_cancel(cancelled)
    process = subprocess.Popen([str(a) for a in args], stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, cwd=cwd, **_kwargs())
    events = queue.Queue()
    def reader(stream, kind):
        try:
            for line in iter(stream.readline, b""):
                events.put((kind, line.decode("utf-8", errors="replace")))
        finally:
            stream.close()
            events.put((kind, None))
    threads = [threading.Thread(target=reader, args=(process.stdout, "out"), daemon=True),
               threading.Thread(target=reader, args=(process.stderr, "err"), daemon=True)]
    for thread in threads:
        thread.start()
    output, errors, ended = [], [], 0
    try:
        while ended < 2:
            _check_cancel(cancelled)
            try:
                kind, line = events.get(timeout=0.15)
            except queue.Empty:
                continue
            if line is None:
                ended += 1
                continue
            target = output if kind == "out" else errors
            target.append(line)
            if len(target) > 2000:
                del target[:1000]
            if progress and duration and line.startswith("out_time_us="):
                try:
                    _notify(progress, 100 * int(line.split("=", 1)[1]) / 1_000_000 / duration, "MP4를 만들고 있습니다")
                except ValueError:
                    pass
        code = process.wait()
        if code:
            raise MediaError("FFmpeg 처리에 실패했습니다.\n" + "".join(errors)[-3500:])
        return "".join(output), "".join(errors)
    finally:
        if process.poll() is None:
            process.kill()
        process.wait()
        for thread in threads:
            thread.join(timeout=2)


def _capture_allow_failure(args):
    try:
        p = subprocess.run([str(a) for a in args], stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, timeout=45, **_kwargs())
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise MediaError(f"영상 정보를 읽지 못했습니다: {exc}") from exc
    return p.returncode, p.stdout.decode("utf-8", "replace"), p.stderr.decode("utf-8", "replace")


def probe(path) -> MediaInfo:
    path = Path(path).resolve()
    if not path.is_file():
        raise MediaError("영상 파일을 찾지 못했습니다.")
    executable = ffmpeg_exe()
    sibling = Path(executable).with_name("ffprobe.exe" if os.name == "nt" else "ffprobe")
    ffprobe = str(sibling) if sibling.is_file() else shutil.which("ffprobe")
    if ffprobe:
        code, output, error = _capture_allow_failure([
            ffprobe, "-v", "error", "-show_format", "-show_streams", "-of", "json", path])
        if not code:
            try:
                data = json.loads(output)
                video = next(s for s in data["streams"] if s.get("codec_type") == "video" and not s.get("disposition", {}).get("attached_pic"))
                audio = next((s for s in data["streams"] if s.get("codec_type") == "audio"), None)
                duration = float(data.get("format", {}).get("duration") or video.get("duration") or 0)
                fps = float(Fraction(video.get("avg_frame_rate", "0/1")))
                if not math.isfinite(fps) or fps <= 0:
                    fps = float(Fraction(video.get("r_frame_rate", "30/1")))
                width, height = int(video["width"]), int(video["height"])
                rotation = 0
                for side in video.get("side_data_list", []):
                    rotation = float(side.get("rotation", rotation))
                rotation = float(video.get("tags", {}).get("rotate", rotation))
                if int(abs(rotation)) % 180 == 90:
                    width, height = height, width
                if duration <= 0 or not math.isfinite(duration):
                    raise ValueError("invalid duration")
                return MediaInfo(path, duration, width, height, min(240.0, max(1.0, fps)), bool(audio),
                                 int(audio.get("channels", 0)) if audio else 0,
                                 int(audio.get("sample_rate", 0)) if audio else 0,
                                 video.get("codec_name", ""), audio.get("codec_name", "") if audio else "")
            except (ValueError, KeyError, StopIteration, ZeroDivisionError):
                pass
    # FFmpeg itself is bundled on Windows, so ffprobe is not an installation prerequisite.
    _, _, output = _capture_allow_failure([executable, "-hide_banner", "-i", path])
    duration_match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", output)
    video_line = next((line for line in output.splitlines() if "Video:" in line and "attached pic" not in line), "")
    dimensions = re.search(r"\b(\d{2,6})x(\d{2,6})\b", video_line)
    if not duration_match or not dimensions:
        raise MediaError("길이와 영상 트랙을 읽을 수 없는 파일입니다.\n" + output[-1500:])
    h, m, s = map(float, duration_match.groups())
    fps_match = re.search(r"([\d.]+) fps", video_line) or re.search(r"([\d.]+) tbr", video_line)
    audio_line = next((line for line in output.splitlines() if "Audio:" in line), "")
    sample_rate = re.search(r"(\d+) Hz", audio_line)
    channels = 2 if "stereo" in audio_line else 1 if "mono" in audio_line else 6 if "5.1" in audio_line else 8 if "7.1" in audio_line else 2
    width, height = map(int, dimensions.groups())
    rotation = re.search(r"rotation of\s*(-?[\d.]+)", output)
    if rotation and int(abs(float(rotation.group(1)))) % 180 == 90:
        width, height = height, width
    return MediaInfo(path, h * 3600 + m * 60 + s, width, height,
                     float(fps_match.group(1)) if fps_match else 30.0, bool(audio_line),
                     channels if audio_line else 0, int(sample_rate.group(1)) if sample_rate else 0,
                     video_line.split("Video:", 1)[1].strip().split()[0].rstrip(","),
                     audio_line.split("Audio:", 1)[1].strip().split()[0].rstrip(",") if audio_line else "")


def _audio_features(info, progress, cancelled):
    """10ms RMS and peak for every channel, preserving channel-local quiet speech."""
    channels = info.audio_channels or 2
    sample_rate, window = 16000, 160
    args = [ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-nostdin", "-i", info.path,
            "-map", "0:a:0", "-vn", "-sn", "-dn", "-af", "aresample=16000:async=1:first_pts=0",
            "-t", str(info.duration), "-ac", str(channels), "-ar", str(sample_rate),
            "-acodec", "pcm_f32le", "-f", "f32le", "pipe:1"]
    process = subprocess.Popen([str(a) for a in args], stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, **_kwargs())
    chunks, errors = queue.Queue(maxsize=16), []
    stop = threading.Event()
    def reader():
        try:
            while not stop.is_set():
                data = process.stdout.read(window * channels * 4 * 100)
                if not data:
                    break
                while not stop.is_set():
                    try:
                        chunks.put(data, timeout=.15)
                        break
                    except queue.Full:
                        continue
        finally:
            process.stdout.close()
            while not stop.is_set():
                try:
                    chunks.put(None, timeout=.15)
                    break
                except queue.Full:
                    continue
    def err_reader():
        for line in iter(process.stderr.readline, b""):
            errors.append(line.decode("utf-8", "replace"))
            if len(errors) > 100:
                errors.pop(0)
        process.stderr.close()
    threads = [threading.Thread(target=reader, daemon=True), threading.Thread(target=err_reader, daemon=True)]
    for thread in threads:
        thread.start()
    rms, peak, pending, count = [], [], b"", 0
    try:
        while True:
            _check_cancel(cancelled)
            try:
                data = chunks.get(timeout=.15)
            except queue.Empty:
                continue
            if data is None:
                break
            pending += data
            frames = len(pending) // (window * channels * 4)
            if not frames:
                continue
            size = frames * window * channels * 4
            samples = np.frombuffer(pending[:size], dtype="<f4").reshape(frames, window, channels)
            pending = pending[size:]
            rms.append(np.sqrt(np.mean(samples.astype(np.float64) ** 2, axis=1)))
            peak.append(np.max(np.abs(samples), axis=1))
            count += frames
            _notify(progress, min(92, 92 * count * .01 / info.duration), "실제 오디오에서 긴 무음을 확인하고 있습니다")
        code = process.wait()
        if code:
            raise MediaError("오디오를 읽지 못했습니다.\n" + "".join(errors)[-2000:])
        if not rms:
            return np.empty((0, channels)), np.empty((0, channels))
        return np.concatenate(rms), np.concatenate(peak)
    finally:
        stop.set()
        if process.poll() is None:
            process.kill()
        process.wait()
        for thread in threads:
            thread.join(timeout=2)


def analyze(path, settings=None, progress=None, cancelled=None) -> Analysis:
    settings = settings or Settings()
    settings.validate()
    _check_cancel(cancelled)
    _notify(progress, 0, "영상 정보를 읽고 있습니다")
    info = probe(path)
    result = Analysis(info, [], settings)
    if not info.has_audio:
        result.warnings.append("음성 트랙이 없어 무음을 자동으로 자르지 않았습니다. 앞뒤 영상만 직접 검토해 주세요.")
        _notify(progress, 100, "음성 트랙 없음 · 자동 컷 없음")
        return result
    rms, peak = _audio_features(info, progress, cancelled)
    if not len(rms):
        result.warnings.append("오디오 샘플을 확인할 수 없어 자동 컷을 만들지 않았습니다.")
        return result
    rms_db = 20 * np.log10(np.maximum(rms, 1e-12))
    peak_db = 20 * np.log10(np.maximum(peak, 1e-12))
    # Recordings with very low signal may contain whispering. Never infer silence there.
    if np.max(peak_db) < -38:
        result.warnings.append("전체 녹음 신호가 매우 작습니다. 작은 목소리를 보호하기 위해 자동 무음 컷을 만들지 않았습니다.")
        _notify(progress, 100, "작은 녹음 신호 보호 · 자동 컷 없음")
        return result
    # Noise-floor adaptation is deliberately conservative: any rise over the local
    # floor, even below the user threshold, preserves breath, laughs and soft voice.
    floor_db = np.percentile(rms_db, 10, axis=0)
    limit_db = np.minimum(settings.threshold_db - 6, np.maximum(-100.0, floor_db) + 4)
    quiet = np.all((rms_db <= limit_db) & (peak_db <= settings.threshold_db), axis=1)
    padded = np.r_[False, quiet, False]
    starts = np.flatnonzero(~padded[:-1] & padded[1:])
    ends = np.flatnonzero(padded[:-1] & ~padded[1:])
    for begin, end in zip(starts, ends):
        _check_cancel(cancelled)
        start, finish = begin * .01, min(end * .01, info.duration)
        # A silent head/tail does not imply filming-button operation.
        if begin == 0 or end == len(quiet):
            continue
        if finish - start + 1e-8 < settings.min_silence:
            continue
        result.silences.append((round(start, 6), round(finish, 6)))
        margin = max(settings.guard, settings.keep_silence / 2)
        cut_start, cut_end = start + margin, finish - margin
        if cut_end - cut_start > .1:
            result.cuts.append(Cut(f"silence-{len(result.cuts)+1}", round(cut_start, 6), round(cut_end, 6),
                                   "silence", f"오디오 확인: {finish-start:.2f}초의 긴 무음 가운데만 제거 · 양쪽 쉼 보호", True))
    result.warnings.append("아주 작은 소리는 무음과 구분하기 어려울 수 있습니다. 자동 컷을 재생하고 필요하면 해제해 주세요.")
    _notify(progress, 100, f"긴 무음 컷 {len(result.cuts)}개 · 앞뒤 촬영 장면은 영상 확인 필요")
    return result


def _merged_cuts(duration, cuts, fps=None):
    intervals = []
    for cut in cuts:
        if not cut.enabled:
            continue
        if not all(math.isfinite(float(v)) for v in (cut.start, cut.end)):
            raise MediaError("컷 지점에 올바르지 않은 숫자가 있습니다.")
        start, end = max(0.0, float(cut.start)), min(duration, float(cut.end))
        if fps:
            # Shrink removals to complete frames; retain extra material at both edges.
            start = math.ceil(start * fps - 1e-7) / fps
            end = duration if cut.end >= duration else math.floor(end * fps + 1e-7) / fps
        if cut.end <= cut.start:
            raise MediaError("컷의 끝 지점은 시작 지점보다 뒤여야 합니다.")
        if end <= start:
            continue
        intervals.append((start, end))
    intervals.sort()
    merged = []
    for start, end in intervals:
        if merged and start <= merged[-1][1] + 1e-8:
            merged[-1] = (merged[-1][0], max(end, merged[-1][1]))
        else:
            merged.append((start, end))
    return merged


def retained_intervals(duration, cuts, fps=None):
    result, cursor = [], 0.0
    for start, end in _merged_cuts(duration, cuts, fps):
        if start > cursor + 1e-8:
            result.append((cursor, start))
        cursor = end
    if cursor < duration - 1e-8:
        result.append((cursor, duration))
    return result


def extract_frame(path, seconds, output_path, width=640) -> Path:
    output_path = Path(output_path)
    if Path(path).resolve() == output_path.resolve():
        raise MediaError("미리보기 경로가 원본과 같습니다.")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    _run([ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
          "-ss", str(max(0, seconds)), "-i", str(Path(path).resolve()), "-frames:v", "1",
          "-vf", f"scale={int(width)}:-2", "-update", "1", str(output_path)])
    if not output_path.is_file() or not output_path.stat().st_size:
        raise MediaError("이 지점의 미리보기 프레임을 읽지 못했습니다.")
    return output_path


def _fingerprint(path):
    stat = path.stat()
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        digest.update(handle.read(1024 * 1024))
        if stat.st_size > 1024 * 1024:
            handle.seek(max(0, stat.st_size - 1024 * 1024))
            digest.update(handle.read(1024 * 1024))
    return {"path": str(path), "filename": path.name, "size_bytes": stat.st_size,
            "mtime_ns": stat.st_mtime_ns, "first_last_1mib_sha256": digest.hexdigest()}


def _claim_name(source, output_dir):
    number = 1
    while True:
        stem = f"{source.stem}_1차컷" + (f"_{number}" if number > 1 else "")
        video = output_dir / (stem + ".mp4")
        mapping = output_dir / (stem + "_타임맵.json")
        lock = output_dir / ("." + stem + ".autocut-lock")
        if video.exists() or mapping.exists():
            number += 1
            continue
        try:
            with lock.open("x", encoding="utf-8") as handle:
                handle.write(f"{os.getpid()}\n")
        except FileExistsError:
            number += 1
            continue
        if video.exists() or mapping.exists():
            lock.unlink(missing_ok=True)
            number += 1
            continue
        return video, mapping, lock


def _publish_no_replace(staged, destination, cancelled=None):
    """Atomic hard-link publication when supported; exclusive-copy fallback otherwise."""
    try:
        os.link(staged, destination)
    except FileExistsError:
        raise MediaError("저장 도중 같은 이름의 결과가 생겨 덮어쓰지 않고 중단했습니다.")
    except OSError:
        created = False
        try:
            with destination.open("xb") as output:
                created = True
                with staged.open("rb") as source:
                    while True:
                        _check_cancel(cancelled)
                        block = source.read(1024 * 1024)
                        if not block:
                            break
                        output.write(block)
                output.flush()
                os.fsync(output.fileno())
        except FileExistsError:
            raise MediaError("같은 이름의 파일이 있어 덮어쓰지 않았습니다.")
        except BaseException:
            if created:
                destination.unlink(missing_ok=True)
            raise


def export_video(path, cuts, output_dir, settings=None, progress=None, cancelled=None):
    settings = settings or Settings()
    settings.validate()
    _check_cancel(cancelled)
    info = probe(path)
    if not info.has_audio:
        raise MediaError("음성 트랙이 없는 원본입니다. 영상·음성이 모두 있는 MP4 저장을 위해 음성이 있는 파일을 선택해 주세요.")
    source = info.path
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    rate = Fraction(info.fps).limit_denominator(1001)
    fps = float(rate)
    # One common frame grid prevents cumulative A/V drift across many joins.
    duration = info.duration
    keep = retained_intervals(duration, cuts, fps)
    if not keep or sum(end - start for start, end in keep) < .1:
        raise MediaError("남는 영상이 너무 짧습니다. 컷 지점을 확인해 주세요.")
    video, mapping, lock = _claim_name(source, output_dir)
    published = []
    total_duration = sum(end - start for start, end in keep)
    try:
        source_before = _fingerprint(source)
        # Each retained interval is sought and rendered independently, bounding both
        # temporal buffers and filter complexity for arbitrarily sparse cuts.
        # Intermediate audio is PCM; AAC is encoded only once at final save.
        with tempfile.TemporaryDirectory(prefix=".autocut-", dir=output_dir) as temp:
            temp = Path(temp)
            chunk_paths = []
            completed_duration = 0.0
            group_size = 1
            for offset in range(0, len(keep), group_size):
                _check_cancel(cancelled)
                group = keep[offset:offset + group_size]
                seek = group[0][0]
                group_duration = sum(end - start for start, end in group)
                count = len(group)
                graph = [f"[0:v:0]fps=fps={rate.numerator}/{rate.denominator}:start_time=0,pad=ceil(iw/2)*2:ceil(ih/2)*2,split={count}" + "".join(f"[vi{i}]" for i in range(count)) + ";",
                         f"[0:a:0]aresample=48000:async=1:first_pts=0,apad,asplit={count}" + "".join(f"[ai{i}]" for i in range(count)) + ";"]
                for i, (start, end) in enumerate(group):
                    begin, finish = start - seek, end - seek
                    graph.append(f"[vi{i}]trim=start={begin:.12f}:end={finish:.12f},setpts=PTS-STARTPTS[v{i}];")
                    graph.append(f"[ai{i}]atrim=start={begin:.12f}:end={finish:.12f},asetpts=PTS-STARTPTS[a{i}];")
                graph.append("".join(f"[v{i}][a{i}]" for i in range(count)) + f"concat=n={count}:v=1:a=1[v][a]")
                script = temp / f"filter{offset:06d}.txt"
                script.write_text("\n".join(graph), encoding="utf-8")
                chunk = temp / f"chunk{offset:06d}.mov"
                def chunk_progress(percent, message):
                    _notify(progress, 88 * (completed_duration + group_duration * percent / 100) / total_duration, message)
                _run([ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-nostdin", "-n",
                      "-ss", f"{seek:.12f}", "-i", source, "-filter_complex_script", script,
                      "-map", "[v]", "-map", "[a]", "-r", f"{rate.numerator}/{rate.denominator}",
                      "-fps_mode", "cfr", "-c:v", "libx264", "-preset", "medium",
                      "-crf", "18", "-pix_fmt", "yuv420p", "-c:a", "pcm_s16le", "-ar", "48000",
                      "-map_metadata", "-1", "-metadata:s:v:0", "rotate=0", "-video_track_timescale", "90000",
                      "-progress", "pipe:1", "-nostats", "-t", f"{group_duration:.12f}", chunk],
                     cancelled=cancelled, progress=chunk_progress, duration=group_duration)
                chunk_paths.append(chunk)
                completed_duration += group_duration
            concat = temp / "concat.txt"
            concat.write_text("\n".join(f"file '{item.name}'" for item in chunk_paths) + "\n", encoding="utf-8")
            staged_video = temp / "result.mp4"
            def final_progress(percent, message):
                _notify(progress, 88 + percent * .08, "음성 인코딩과 MP4 마무리 중입니다")
            _run([ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-nostdin", "-n",
                  "-f", "concat", "-safe", "0", "-i", concat, "-map", "0:v:0", "-map", "0:a:0",
                  "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart",
                  "-map_metadata", "-1", "-video_track_timescale", "90000", "-progress", "pipe:1", "-nostats", staged_video],
                 cancelled=cancelled, progress=final_progress, duration=total_duration, cwd=temp)
            _check_cancel(cancelled)
            _notify(progress, 97, "저장 결과의 영상·음성 트랙을 확인하고 있습니다")
            output_info = probe(staged_video)
            if not output_info.has_audio or output_info.video_codec != "h264" or output_info.audio_codec != "aac":
                raise MediaError("출력의 H.264 영상/AAC 음성 확인에 실패해 결과를 저장하지 않았습니다.")
            if abs(output_info.duration - total_duration) > max(.15, 2 / fps):
                raise MediaError("출력 길이가 타임맵과 달라 결과를 저장하지 않았습니다.")
            if _fingerprint(source) != source_before:
                raise MediaError("작업 도중 원본 파일이 변경되어 저장을 중단했습니다.")
            segments, cursor = [], 0.0
            for index, (start, end) in enumerate(keep):
                length = end - start
                segments.append({"index": index, "source_start": round(start, 9), "source_end": round(end, 9),
                                 "output_start": round(cursor, 9), "output_end": round(cursor + length, 9), "speed": 1.0})
                cursor += length
            payload = {"schema_version": 1, "app": "용심리 AutoCut", "stage": 1,
                       "created_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                       "time_unit": "seconds", "interval_convention": "start inclusive, end exclusive",
                       "timeline_origin": "source media presentation start", "frame_rate": str(rate),
                       "timeline_precision_seconds": round(1 / fps, 9),
                       "source": {**source_before, "duration": info.duration},
                       "output": {"filename": video.name, "duration": round(cursor, 9),
                                  "container_duration": output_info.duration, "video_codec": "h264", "audio_codec": "aac",
                                  "width": output_info.width, "height": output_info.height},
                       "settings": asdict(settings),
                       "cuts": [{**asdict(cut), "start": float(cut.start), "end": float(cut.end)} for cut in cuts],
                       "applied_removals": [{"source_start": round(start, 9), "source_end": round(end, 9)}
                                            for start, end in _merged_cuts(duration, cuts, fps)],
                       "segments": segments,
                       "notes": ["Cuts are shrunk to complete output frames to protect boundaries.",
                                 "Output uses the source reported frame rate; VFR is resampled to this frame grid.",
                                 "AAC/container padding is excluded from the retained-segment timeline."]}
            staged_map = temp / "timemap.json"
            staged_map.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            _check_cancel(cancelled)
            _publish_no_replace(staged_video, video, cancelled)
            published.append(video)
            _publish_no_replace(staged_map, mapping, cancelled)
            published.append(mapping)
        _notify(progress, 100, "MP4와 타임맵을 저장했습니다")
        return video, mapping
    except BaseException:
        for item in published:
            item.unlink(missing_ok=True)
        raise
    finally:
        lock.unlink(missing_ok=True)
