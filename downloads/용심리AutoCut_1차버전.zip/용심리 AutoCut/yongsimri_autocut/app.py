"""용심리 AutoCut: local first-pass desktop editing UI."""
from __future__ import annotations

import argparse
import dataclasses
import os
import sys
import tempfile
import threading
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal, QUrl, QTimer
from PySide6.QtGui import QPixmap, QFont, QDesktopServices
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer, QVideoSink
from PySide6.QtMultimediaWidgets import QVideoWidget
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFileDialog, QDoubleSpinBox, QSlider, QTableWidget,
    QTableWidgetItem, QHeaderView, QProgressBar, QMessageBox, QTabWidget,
    QScrollArea, QSplitter, QCheckBox, QFrame, QGroupBox, QFormLayout,
    QSizePolicy, QAbstractItemView,
)

from .engine import Settings, Cut, analyze, probe, export_video


def stamp(seconds: float) -> str:
    seconds = max(0.0, seconds)
    minutes, sec = divmod(seconds, 60)
    hours, minutes = divmod(int(minutes), 60)
    return f"{hours:02}:{minutes:02}:{sec:06.3f}"


class CpuVideoPreview(QLabel):
    """Paint actual decoded frames when there is no native window surface.

    Qt's offscreen platform cannot paint QVideoWidget's native surface. This
    fallback is used only there; normal desktop platforms keep QVideoWidget.
    """
    def __init__(self):
        super().__init__("영상을 불러오면 원본 미리보기를 표시합니다")
        self.setAlignment(Qt.AlignCenter)
        self._sink = QVideoSink(self)
        self._image = None
        self._sink.videoFrameChanged.connect(self.show_frame)

    def videoSink(self):
        return self._sink

    def show_frame(self, frame):
        if frame.isValid():
            image = frame.toImage()
            if not image.isNull():
                self._image = image
                self.paint_frame()

    def paint_frame(self):
        if self._image is not None:
            self.setPixmap(QPixmap.fromImage(self._image).scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.paint_frame()


class Worker(QThread):
    progress = Signal(float, str)
    succeeded = Signal(object)
    failed = Signal(str)
    cancelled = Signal()

    def __init__(self, fn):
        super().__init__()
        self.fn = fn
        self.stop_event = threading.Event()

    def run(self):
        try:
            result = self.fn(self.progress.emit, self.stop_event.is_set)
            # A returned export is already committed. A late cancel click must
            # not misreport published MP4/time-map files as cancelled.
            self.succeeded.emit(result)
        except Exception as exc:
            if self.stop_event.is_set() or exc.__class__.__name__ == "Cancelled":
                self.cancelled.emit()
            else:
                self.failed.emit(str(exc) or exc.__class__.__name__)


class AutoCutWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("용심리 AutoCut · 1차 편집")
        self.resize(1360, 920)
        self.setMinimumSize(1100, 760)
        self.source: Path | None = None
        self.info = None
        self.analysis = None
        self.settings_dirty = False
        self.cuts: list[Cut] = []
        self.worker: Worker | None = None
        self.cache = tempfile.TemporaryDirectory(prefix="yongsimri-preview-")
        self._filling = False
        self._preview_end: int | None = None
        self._preview_loop = False
        self._preview_start = 0
        self.last_output: Path | None = None
        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        self.audio.setVolume(0.8)
        self.player.setAudioOutput(self.audio)
        self.build_ui()
        self.player.positionChanged.connect(self.position_changed)
        self.player.durationChanged.connect(lambda ms: self.seek.setMaximum(ms))
        self.player.playbackStateChanged.connect(self.playback_changed)
        self.player.errorOccurred.connect(self.playback_error)
        self.update_summary()

    def build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(24, 18, 24, 18)
        root.setSpacing(12)
        top = QHBoxLayout()
        identity = QVBoxLayout()
        title = QLabel("용심리 AutoCut")
        title.setObjectName("title")
        identity.addWidget(title)
        subtitle = QLabel("내 PC에서 만드는 1차 컷  ·  최종 편집은 Vrew에서")
        subtitle.setObjectName("muted")
        identity.addWidget(subtitle)
        top.addLayout(identity)
        top.addStretch()
        local = QLabel("●  영상 업로드 없음")
        local.setObjectName("badge")
        top.addWidget(local)
        root.addLayout(top)
        self.steps = []
        steps = QHBoxLayout()
        for i, name in enumerate(("영상 불러오기", "1차 컷 분석", "자를 구간 확인", "MP4 저장"), 1):
            item = QLabel(f"{i:02}   {name}")
            item.setObjectName("step")
            steps.addWidget(item)
            self.steps.append(item)
        root.addLayout(steps)

        toolbar = QHBoxLayout()
        self.open_btn = QPushButton("＋  영상 불러오기")
        self.open_btn.setObjectName("primary")
        self.open_btn.clicked.connect(lambda: self.open_file())
        toolbar.addWidget(self.open_btn)
        self.file_label = QLabel("MP4 파일을 선택해 주세요")
        self.file_label.setObjectName("muted")
        self.file_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        toolbar.addWidget(self.file_label, 1)
        root.addLayout(toolbar)

        splitter = QSplitter(Qt.Horizontal)
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 8, 0)
        lv.setSpacing(10)
        self.video = CpuVideoPreview() if QApplication.platformName() == "offscreen" else QVideoWidget()
        self.video.setMinimumSize(340, 140)
        self.video.setStyleSheet("background: #080d16; border-radius: 12px;")
        if isinstance(self.video, CpuVideoPreview):
            self.player.setVideoSink(self.video.videoSink())
        else:
            self.player.setVideoOutput(self.video)
        lv.addWidget(self.video, 1)
        self.video_hint = QLabel("원본 미리보기 · 소리와 표정을 확인한 뒤 컷을 선택하세요")
        self.video_hint.setObjectName("muted")
        lv.addWidget(self.video_hint)
        self.seek = QSlider(Qt.Horizontal)
        self.seek.setRange(0, 0)
        self.seek.sliderMoved.connect(self.seek_to)
        lv.addWidget(self.seek)
        playback = QHBoxLayout()
        self.play_btn = QPushButton("▶  재생")
        self.play_btn.clicked.connect(self.toggle_play)
        self.play_btn.setEnabled(False)
        playback.addWidget(self.play_btn)
        back = QPushButton("−1초")
        back.clicked.connect(lambda: self.seek_to(max(0, self.player.position() - 1000)))
        playback.addWidget(back)
        forward = QPushButton("＋1초")
        forward.clicked.connect(lambda: self.seek_to(self.player.position() + 1000))
        playback.addWidget(forward)
        self.clock = QLabel("00:00:00.000 / 00:00:00.000")
        self.clock.setObjectName("muted")
        playback.addWidget(self.clock, 1, Qt.AlignRight)
        lv.addLayout(playback)

        settings = QGroupBox("긴 무음 줄이기")
        settings.setMinimumHeight(220)
        sf = QFormLayout(settings)
        self.min_silence = self.seconds_spin(2.5, 1, 60)
        self.keep_silence = self.seconds_spin(1.0, .5, 10)
        self.threshold = QDoubleSpinBox()
        self.threshold.setDecimals(0)
        self.threshold.setRange(-80, -35)
        self.threshold.setValue(-48)
        self.threshold.setSuffix(" dBFS")
        self.threshold.setToolTip("값을 낮추면 작은 소리를 더 많이 보호합니다. 너무 높이면 작은 목소리가 무음으로 분류될 수 있습니다.")
        sf.addRow("이 길이 이상인 무음만", self.min_silence)
        sf.addRow("무음마다 남길 쉼", self.keep_silence)
        sf.addRow("무음 기준 · 낮을수록 보수적", self.threshold)
        note = QLabel("무음 가운데만 제안합니다. 짧은 쉼·반복 대사·웃음은\n의미를 판단해 지우지 않습니다. 작은 소리는 직접 확인하세요.")
        note.setObjectName("muted")
        note.setWordWrap(True)
        sf.addRow(note)
        lv.addWidget(settings)
        self.analyze_btn = QPushButton("1차 컷 분석")
        self.analyze_btn.setObjectName("primary")
        self.analyze_btn.clicked.connect(self.start_analysis)
        self.analyze_btn.setEnabled(False)
        lv.addWidget(self.analyze_btn)
        # Keep all controls reachable on smaller Windows displays / scaling.
        # Scroll the panel instead of compressing form labels into one another.
        left.setMinimumHeight(570)
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        left_scroll.setFrameShape(QFrame.NoFrame)
        left_scroll.setStyleSheet("QScrollArea { border: 0; }")
        left_scroll.setMinimumWidth(380)
        left_scroll.setWidget(left)
        splitter.addWidget(left_scroll)

        right = QWidget()
        rv = QVBoxLayout(right)
        rv.setContentsMargins(8, 0, 0, 0)
        self.tabs = QTabWidget()
        review = QWidget()
        rl = QVBoxLayout(review)
        rl.setContentsMargins(12, 14, 12, 12)
        review_title = QLabel("체크된 구간만 잘립니다")
        review_title.setObjectName("sectionTitle")
        rl.addWidget(review_title)
        hint = QLabel("행을 선택해 원본을 재생하고, 필요하면 체크를 해제하세요.\n시작·끝 시간은 원본 기준이며 직접 조정할 수 있습니다.")
        hint.setObjectName("muted")
        hint.setWordWrap(True)
        rl.addWidget(hint)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["자르기", "구분", "시작(초)", "끝(초)", "근거"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        for col, size in ((0, 54), (1, 86), (2, 98), (3, 98)):
            self.table.setColumnWidth(col, size)
        self.table.itemChanged.connect(self.check_changed)
        self.table.itemSelectionChanged.connect(self.selection_changed)
        rl.addWidget(self.table, 1)
        row_controls = QHBoxLayout()
        self.preview_btn = QPushButton("▶  선택 구간 앞뒤 재생")
        self.preview_btn.clicked.connect(self.preview_selected)
        row_controls.addWidget(self.preview_btn)
        self.loop_check = QCheckBox("반복")
        row_controls.addWidget(self.loop_check)
        row_controls.addStretch()
        clear = QPushButton("모두 해제")
        clear.clicked.connect(self.clear_checks)
        row_controls.addWidget(clear)
        rl.addLayout(row_controls)
        self.empty_label = QLabel("영상을 분석하면 실제 오디오에서 찾은 긴 무음이 표시됩니다.")
        self.empty_label.setObjectName("muted")
        self.empty_label.setWordWrap(True)
        rl.addWidget(self.empty_label)
        self.tabs.addTab(review, "자를 구간 확인")

        edges = QWidget()
        el = QVBoxLayout(edges)
        el.setContentsMargins(12, 14, 12, 12)
        edge_title = QLabel("촬영 버튼 잡컷 · 화면으로 확인")
        edge_title.setObjectName("sectionTitle")
        el.addWidget(edge_title)
        self.edge_explanation = QLabel("앞뒤 실제 프레임을 분석한 뒤 보여 드립니다. 화면 변화만으로\n폰 조작을 확정하지 않으며, 앞뒤 구간은 자동 선택하지 않습니다.")
        self.edge_explanation.setObjectName("muted")
        self.edge_explanation.setWordWrap(True)
        el.addWidget(self.edge_explanation)
        self.start_strip = self.make_strip(el, "영상 시작 · 사진을 누르면 해당 위치로 이동")
        self.end_strip = self.make_strip(el, "영상 끝 · 표정과 마무리 리액션도 확인")
        boundary = QGroupBox("직접 정한 앞뒤 구간만 자르기")
        bf = QFormLayout(boundary)
        self.trim_start = QCheckBox("시작부터 이 시점 전까지 자르기")
        self.trim_end = QCheckBox("이 시점부터 영상 끝까지 자르기")
        self.start_time = self.seconds_spin(0, 0, 86400, 3)
        self.end_time = self.seconds_spin(0, 0, 86400, 3)
        start_row = QHBoxLayout()
        start_row.addWidget(self.start_time)
        start_now = QPushButton("현재 위치")
        start_now.clicked.connect(lambda: self.start_time.setValue(self.player.position() / 1000))
        start_row.addWidget(start_now)
        end_row = QHBoxLayout()
        end_row.addWidget(self.end_time)
        end_now = QPushButton("현재 위치")
        end_now.clicked.connect(lambda: self.end_time.setValue(self.player.position() / 1000))
        end_row.addWidget(end_now)
        bf.addRow(self.trim_start, start_row)
        bf.addRow(self.trim_end, end_row)
        el.addWidget(boundary)
        edge_play = QHBoxLayout()
        preview_start = QPushButton("▶  영상 처음 8초")
        preview_start.clicked.connect(lambda: self.preview_range(0, min(8, self.duration)))
        preview_end = QPushButton("▶  영상 마지막 8초")
        preview_end.clicked.connect(lambda: self.preview_range(max(0, self.duration - 8), self.duration))
        edge_play.addWidget(preview_start)
        edge_play.addWidget(preview_end)
        el.addLayout(edge_play)
        el.addStretch()
        edge_scroll = QScrollArea()
        edge_scroll.setWidgetResizable(True)
        edge_scroll.setWidget(edges)
        self.tabs.addTab(edge_scroll, "앞뒤 화면 · 직접 조정")
        rv.addWidget(self.tabs, 1)
        self.summary = QLabel()
        self.summary.setObjectName("summary")
        self.summary.setWordWrap(True)
        rv.addWidget(self.summary)
        save_row = QHBoxLayout()
        self.save_btn = QPushButton("MP4 저장")
        self.save_btn.setObjectName("primary")
        self.save_btn.setMinimumHeight(44)
        self.save_btn.clicked.connect(self.start_export)
        self.save_btn.setEnabled(False)
        save_row.addWidget(self.save_btn, 1)
        self.show_output_btn = QPushButton("저장 폴더 열기")
        self.show_output_btn.clicked.connect(self.show_output)
        self.show_output_btn.setEnabled(False)
        save_row.addWidget(self.show_output_btn)
        rv.addLayout(save_row)
        splitter.addWidget(right)
        splitter.setSizes([480, 820])
        root.addWidget(splitter, 1)
        status_row = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setMaximumWidth(200)
        self.progress.setTextVisible(False)
        status_row.addWidget(self.progress)
        self.status = QLabel("준비됨 · 원본과 기존 결과는 덮어쓰지 않습니다")
        self.status.setObjectName("muted")
        self.status.setWordWrap(True)
        status_row.addWidget(self.status, 1)
        self.cancel_btn = QPushButton("작업 취소")
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.clicked.connect(self.cancel_work)
        status_row.addWidget(self.cancel_btn)
        root.addLayout(status_row)
        footer = QLabel("H.264 / AAC MP4 + 타임맵 자동 저장  ·  배속·자막·효과·색보정 없음")
        footer.setObjectName("muted")
        root.addWidget(footer)
        for control in (self.trim_start, self.trim_end):
            control.toggled.connect(self.update_summary)
        for control in (self.start_time, self.end_time):
            control.valueChanged.connect(self.update_summary)
        for control in (self.min_silence, self.keep_silence, self.threshold):
            control.valueChanged.connect(self.settings_changed)
        self.apply_style()

    @property
    def duration(self):
        return float(self.info.duration) if self.info else 0.0

    @staticmethod
    def seconds_spin(value, low, high, decimals=1):
        spin = QDoubleSpinBox()
        spin.setRange(low, high)
        spin.setDecimals(decimals)
        spin.setSingleStep(.1)
        spin.setValue(value)
        spin.setSuffix(" 초")
        return spin

    def make_strip(self, layout, label):
        heading = QLabel(label)
        heading.setObjectName("muted")
        layout.addWidget(heading)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(134)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        widget = QWidget()
        hl = QHBoxLayout(widget)
        hl.setContentsMargins(4, 4, 4, 4)
        hl.addWidget(QLabel("분석 후 실제 프레임을 표시합니다"))
        scroll.setWidget(widget)
        layout.addWidget(scroll)
        return hl

    def apply_style(self):
        self.setStyleSheet("""
        QMainWindow, QWidget { background: #101927; color: #e6edf6; font-size: 13px; }
        QLabel#title { font-size: 28px; font-weight: 700; color: #f8fbff; }
        QLabel#muted { color: #a7b8cc; font-size: 12px; }
        QLabel#badge { color: #71dfc1; background: #163b39; padding: 9px 13px; border-radius: 14px; }
        QLabel#step { color: #c0d1e4; background: #1b293d; border-radius: 7px; padding: 11px; font-weight: 600; }
        QLabel#sectionTitle { font-size: 16px; font-weight: 600; }
        QLabel#summary { background: #193b3a; color: #c3f4e8; padding: 13px; border-radius: 8px; }
        QPushButton { background: #24354b; border: 1px solid #3a4c63; border-radius: 6px; padding: 8px 12px; }
        QPushButton:hover { background: #314861; border-color: #62c5b4; }
        QPushButton:pressed { background: #1c293b; }
        QPushButton:disabled { color: #64748b; background: #1a2637; border-color: #28374a; }
        QPushButton#primary { background: #67dfbe; color: #0b2926; border-color: #67dfbe; font-weight: 700; }
        QPushButton#primary:hover { background: #8debd1; }
        QPushButton#primary:disabled { background: #254a48; color: #7c9998; border-color: #254a48; }
        QGroupBox { border: 1px solid #2d4057; border-radius: 8px; margin-top: 10px; padding: 13px 10px 10px; }
        QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 6px; color: #d9e4f1; }
        QDoubleSpinBox { border: 1px solid #40536d; border-radius: 5px; padding: 6px; background: #172438; min-width: 80px; }
        QTableWidget { background: #121f30; alternate-background-color: #172638; border: 1px solid #2d4057; border-radius: 6px; gridline-color: #27394f; }
        QTableWidget::item { padding: 5px; }
        QTableWidget::item:selected { background: #224d52; color: #eefcf8; }
        QHeaderView::section { background: #223247; color: #c5d4e6; padding: 8px 4px; border: 0; }
        QTabWidget::pane { border: 1px solid #2d4057; border-radius: 8px; }
        QTabBar::tab { background: #18263a; padding: 11px 18px; color: #a7b8cc; }
        QTabBar::tab:selected { background: #243a4c; color: #7ce6c9; border-bottom: 2px solid #67dfbe; }
        QSlider::groove:horizontal { background: #30435b; height: 5px; border-radius: 2px; }
        QSlider::handle:horizontal { background: #67dfbe; width: 12px; margin: -4px 0; border-radius: 6px; }
        QProgressBar { background: #23364a; border: 0; border-radius: 3px; max-height: 7px; }
        QProgressBar::chunk { background: #67dfbe; border-radius: 3px; }
        QScrollArea { border: 1px solid #2d4057; border-radius: 6px; }
        QCheckBox { spacing: 7px; }
        QCheckBox::indicator { width: 17px; height: 17px; }
        QToolTip { color: #e6edf6; background: #23364a; border: 1px solid #526b88; padding: 6px; }
        """)

    def settings(self):
        return Settings(min_silence=self.min_silence.value(), keep_silence=self.keep_silence.value(), threshold_db=self.threshold.value(), guard=.25)

    def settings_changed(self):
        self.settings_dirty = True
        if self.analysis and not self.worker:
            self.save_btn.setEnabled(False)
            self.status.setText("설정이 바뀌었습니다. ‘1차 컷 분석’을 다시 눌러 주세요.")

    def set_busy(self, busy):
        self.open_btn.setEnabled(not busy)
        self.analyze_btn.setEnabled(not busy and self.info is not None)
        self.save_btn.setEnabled(not busy and self.analysis is not None and not self.settings_dirty)
        self.cancel_btn.setEnabled(busy)
        self.table.setEnabled(not busy)
        for widget in (self.min_silence, self.keep_silence, self.threshold, self.trim_start, self.trim_end, self.start_time, self.end_time):
            widget.setEnabled(not busy)

    def begin_work(self, fn, on_success):
        if self.worker:
            return
        self.player.pause()
        self._preview_end = None
        self.set_busy(True)
        self.progress.setValue(0)
        worker = Worker(fn)
        self.worker = worker
        worker.progress.connect(self.on_progress)
        worker.succeeded.connect(on_success)
        worker.failed.connect(self.work_failed)
        worker.cancelled.connect(lambda: self.status.setText("작업을 취소했습니다. 원본은 그대로입니다."))
        worker.finished.connect(self.work_finished)
        worker.start()

    def on_progress(self, value, message):
        self.progress.setValue(max(0, min(100, round(value))))
        self.status.setText(message)

    def work_finished(self):
        worker = self.worker
        self.worker = None
        if worker:
            worker.deleteLater()
        self.set_busy(False)

    def work_failed(self, message):
        self.status.setText("작업을 완료하지 못했습니다. 원본은 그대로입니다.")
        QMessageBox.warning(self, "작업 확인", message)

    def cancel_work(self):
        if self.worker:
            self.worker.stop_event.set()
            self.cancel_btn.setEnabled(False)
            self.status.setText("취소 중입니다. 임시 파일을 정리하고 있습니다…")

    def open_file(self, path=None):
        if self.worker:
            return
        if not path:
            path, _ = QFileDialog.getOpenFileName(self, "편집할 원본 MP4 선택", "", "MP4 영상 (*.mp4 *.MP4);;모든 영상 (*)")
        if not path:
            return
        path = Path(path).resolve()
        self.player.stop()
        self.player.setSource(QUrl())
        self.source = path
        self.info = None
        self.analysis = None
        self.settings_dirty = False
        self.cuts = []
        self.fill_table()
        self.file_label.setText(path.name)
        self.file_label.setToolTip(str(path))
        self.empty_label.setText("영상을 분석하면 실제 오디오에서 찾은 긴 무음이 표시됩니다.")
        self.video_hint.setText("원본 미리보기 · 소리와 표정을 확인한 뒤 컷을 선택하세요")
        self.play_btn.setEnabled(False)
        self.trim_start.setChecked(False)
        self.trim_end.setChecked(False)
        self.last_output = None
        self.show_output_btn.setEnabled(False)
        self.clear_strips()
        self.edge_explanation.setText("분석 후 새 영상의 앞뒤 실제 프레임을 보여 드립니다. 화면 변화만으로 촬영 버튼 조작을 확정하지 않으며, 앞뒤 구간은 자동 선택하지 않습니다.")
        self.cache.cleanup()
        self.cache = tempfile.TemporaryDirectory(prefix="yongsimri-preview-")
        self.begin_work(lambda progress, cancelled: probe(path), self.loaded)
        self.status.setText("원본 영상 정보를 확인하고 있습니다…")

    def loaded(self, info):
        self.info = info
        self.player.setSource(QUrl.fromLocalFile(str(self.source)))
        self.play_btn.setEnabled(True)
        self.start_time.setMaximum(self.duration)
        self.end_time.setMaximum(self.duration)
        self.start_time.setValue(0)
        self.end_time.setValue(self.duration)
        self.seek.setMaximum(round(self.duration * 1000))
        self.video_hint.setText(f"원본 미리보기 · {info.width} × {info.height} · {stamp(self.duration)}")
        self.status.setText("영상을 불러왔습니다. 무음 설정을 확인하고 ‘1차 컷 분석’을 누르세요.")
        self.progress.setValue(100)
        self.update_summary()

    def start_analysis(self):
        if not self.source or not self.info:
            return
        try:
            settings = self.settings()
        except (ValueError, TypeError) as exc:
            QMessageBox.information(self, "무음 설정 확인", str(exc))
            return
        if settings.keep_silence >= settings.min_silence:
            QMessageBox.information(self, "무음 길이 확인", "남길 쉼은 무음을 찾는 최소 길이보다 짧게 설정해 주세요.")
            return
        source = self.source
        cache_path = Path(self.cache.name)
        self.analysis = None
        self.cuts = []
        self.fill_table()
        def task(progress, cancelled):
            result = analyze(source, settings, progress=lambda p,m: progress(p * .8, m), cancelled=cancelled)
            from .edges import review_edges
            edge = review_edges(source, result.info, cache_path, progress=lambda p,m: progress(80 + p * .2, m), cancelled=cancelled)
            result.cuts.extend(edge.suggestions)
            return result, edge
        self.begin_work(task, self.analyzed)

    def analyzed(self, value):
        self.analysis, edge = value
        self.settings_dirty = False
        self.info = self.analysis.info
        self.cuts = self.analysis.cuts
        self.fill_table()
        self.fill_strip(self.start_strip, edge.start_frames)
        self.fill_strip(self.end_strip, edge.end_frames)
        self.edge_explanation.setText(edge.explanation)
        self.tabs.setCurrentIndex(0)
        warnings = getattr(self.analysis, "warnings", [])
        count = sum(c.kind == "silence" for c in self.cuts)
        self.empty_label.setText("무음 후보가 없습니다. 앞뒤 화면을 확인한 뒤 그대로 저장할 수도 있습니다." if not count else "작은 목소리·숨소리가 들어 있으면 체크를 해제해 남겨 주세요.")
        self.status.setText(f"분석 완료 · 긴 무음 {count}곳. 앞뒤 화면도 확인해 주세요." + (" · " + " / ".join(warnings) if warnings else ""))
        self.progress.setValue(100)
        self.update_summary()

    def clear_strips(self):
        for layout in (self.start_strip, self.end_strip):
            while layout.count():
                item = layout.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()

    def fill_strip(self, layout, frames):
        while layout.count():
            item = layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        for seconds, path in frames:
            box = QWidget()
            vertical = QVBoxLayout(box)
            vertical.setContentsMargins(0, 0, 0, 0)
            vertical.setSpacing(2)
            button = QPushButton()
            pixmap = QPixmap(str(path))
            if not pixmap.isNull():
                from PySide6.QtGui import QIcon
                button.setIcon(QIcon(pixmap))
                button.setIconSize(pixmap.scaled(126, 72, Qt.KeepAspectRatio).size())
            button.setFixedSize(136, 80)
            button.setToolTip(f"{stamp(seconds)}로 이동")
            button.clicked.connect(lambda checked=False,t=seconds: self.seek_to(round(t * 1000)))
            vertical.addWidget(button)
            caption = QLabel(stamp(seconds))
            caption.setAlignment(Qt.AlignCenter)
            caption.setObjectName("muted")
            vertical.addWidget(caption)
            layout.addWidget(box)
        layout.addStretch()

    def fill_table(self):
        self._filling = True
        self.table.setRowCount(len(self.cuts))
        for row, cut in enumerate(self.cuts):
            check = QTableWidgetItem()
            check.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            check.setCheckState(Qt.Checked if cut.enabled else Qt.Unchecked)
            self.table.setItem(row, 0, check)
            kind = "긴 무음" if cut.kind == "silence" else "앞뒤 검토"
            self.table.setItem(row, 1, QTableWidgetItem(kind))
            for col, attr in ((2, "start"), (3, "end")):
                spin = self.seconds_spin(getattr(cut, attr), 0, self.duration or 86400, 3)
                spin.setSuffix("")
                spin.valueChanged.connect(lambda value,r=row,a=attr: self.cut_time_changed(r,a,value))
                self.table.setCellWidget(row, col, spin)
            reason = QTableWidgetItem(cut.reason)
            reason.setToolTip(cut.reason)
            self.table.setItem(row, 4, reason)
            self.table.setRowHeight(row, 43)
        self._filling = False
        self.update_summary()

    def check_changed(self, item):
        if not self._filling and item.column() == 0:
            self.cuts[item.row()].enabled = item.checkState() == Qt.Checked
            self.update_summary()

    def cut_time_changed(self, row, attr, value):
        if not self._filling and row < len(self.cuts):
            setattr(self.cuts[row], attr, value)
            self.update_summary()

    def clear_checks(self):
        for row in range(self.table.rowCount()):
            self.table.item(row, 0).setCheckState(Qt.Unchecked)
        self.trim_start.setChecked(False)
        self.trim_end.setChecked(False)

    def selection_changed(self):
        row = self.table.currentRow()
        if row >= 0 and row < len(self.cuts):
            self.seek_to(round(max(0, self.cuts[row].start - 1) * 1000))

    def selected_cuts(self):
        cuts = [dataclasses.replace(c) for c in self.cuts]
        if self.trim_start.isChecked() and self.start_time.value() > 0:
            cuts.append(Cut("manual-start", 0, self.start_time.value(), "manual_edge", "사용자가 시작 화면을 확인하고 직접 지정", True))
        if self.trim_end.isChecked() and self.end_time.value() < self.duration:
            cuts.append(Cut("manual-end", self.end_time.value(), self.duration, "manual_edge", "사용자가 끝 화면을 확인하고 직접 지정", True))
        return cuts

    def update_summary(self, *_):
        duration = self.duration
        ranges = sorted((max(0, c.start), min(duration, c.end)) for c in self.selected_cuts() if c.enabled and c.end > c.start)
        merged = []
        for start, end in ranges:
            if merged and start <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], end)
            else:
                merged.append([start, end])
        removed = sum(max(0, b-a) for a,b in merged)
        if not duration:
            self.summary.setText("원본을 선택하면 예상 길이가 표시됩니다.")
        else:
            self.summary.setText(f"선택 {len(ranges)}곳 · 약 {removed:.2f}초 줄임\n원본 {stamp(duration)}  →  예상 {stamp(max(0, duration-removed))}")

    def preview_selected(self):
        row = self.table.currentRow()
        if row >= 0 and row < len(self.cuts):
            cut = self.cuts[row]
            self.preview_range(max(0, cut.start - 1.2), min(self.duration, cut.end + 1.2))

    def preview_range(self, start, end):
        if not self.source or end <= start:
            return
        self._preview_start = round(start * 1000)
        self._preview_end = round(end * 1000)
        self._preview_loop = self.loop_check.isChecked()
        self.player.setPosition(self._preview_start)
        self.player.play()

    def seek_to(self, position):
        self._preview_end = None
        self.player.setPosition(min(max(0, position), round(self.duration * 1000)))

    def toggle_play(self):
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()
        else:
            self._preview_end = None
            self.player.play()

    def playback_changed(self, state):
        self.play_btn.setText("Ⅱ  일시 정지" if state == QMediaPlayer.PlayingState else "▶  재생")

    def position_changed(self, position):
        if not self.seek.isSliderDown():
            self.seek.setValue(position)
        self.clock.setText(f"{stamp(position/1000)} / {stamp(self.duration)}")
        if self._preview_end is not None and position >= self._preview_end:
            if self._preview_loop:
                self.player.setPosition(self._preview_start)
            else:
                self.player.pause()
                self._preview_end = None

    def playback_error(self, *_):
        if self.player.error() != QMediaPlayer.NoError:
            self.status.setText("미리보기 재생 오류: " + self.player.errorString() + " · 분석·저장은 FFmpeg로 별도 처리됩니다.")

    def start_export(self):
        if not self.source or not self.analysis or self.settings_dirty:
            return
        cuts = self.selected_cuts()
        invalid = [c for c in cuts if c.enabled and (c.start < 0 or c.end > self.duration + .001 or c.end <= c.start)]
        if invalid:
            QMessageBox.information(self, "자를 구간 확인", "선택한 구간의 끝은 시작보다 뒤에 있어야 합니다. 시간 값을 확인해 주세요.")
            return
        folder = QFileDialog.getExistingDirectory(self, "MP4와 타임맵을 저장할 폴더", str(self.source.parent))
        if not folder:
            return
        source, settings = self.source, self.analysis.settings
        self.begin_work(lambda progress,cancelled: export_video(source, cuts, Path(folder), settings=settings, progress=progress, cancelled=cancelled), self.exported)

    def exported(self, result):
        video, timemap = map(Path, result)
        self.last_output = video
        self.show_output_btn.setEnabled(True)
        self.progress.setValue(100)
        self.status.setText(f"저장 완료 · {video.name}")
        QMessageBox.information(self, "MP4 저장 완료", f"Vrew에 아래 MP4를 가져오세요.\n\n{video}\n\n타임맵도 같은 폴더에 저장했습니다.\n{timemap.name}\n\n원본과 기존 결과는 덮어쓰지 않았습니다.")

    def show_output(self):
        if self.last_output:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.last_output.parent)))

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            self.cancel_work()
            self.status.setText("작업 취소와 임시 파일 정리가 끝난 뒤 창을 닫아 주세요.")
            event.ignore()
            return
        self.player.stop()
        self.player.setSource(QUrl())
        self.cache.cleanup()
        event.accept()


def main(argv=None):
    parser = argparse.ArgumentParser(description="용심리 AutoCut 로컬 데스크톱 앱")
    parser.add_argument("--open", dest="open_path", help="시작할 때 불러올 원본 MP4")
    parser.add_argument("--analyze", action="store_true", help="불러온 영상을 자동 분석 (검증용)")
    parser.add_argument("--screenshot", help="창을 PNG로 저장 (검증용)")
    args = parser.parse_args(argv)
    app = QApplication(sys.argv[:1])
    app.setApplicationName("용심리 AutoCut")
    app.setOrganizationName("Yongsimri AutoCut")
    app.setFont(QFont("Malgun Gothic" if os.name == "nt" else "Noto Sans CJK KR", 10))
    window = AutoCutWindow()
    window.show()
    if args.open_path:
        QTimer.singleShot(100, lambda: window.open_file(args.open_path))
    if args.analyze:
        timer = QTimer(window)
        def maybe_analyze():
            if window.info and not window.worker and not window.analysis:
                timer.stop()
                window.start_analysis()
        timer.timeout.connect(maybe_analyze)
        timer.start(250)
    if args.screenshot:
        screen_timer = QTimer(window)
        def maybe_screenshot():
            if (not args.analyze or window.analysis) and not window.worker:
                window.grab().save(args.screenshot)
                screen_timer.stop()
        screen_timer.timeout.connect(maybe_screenshot)
        screen_timer.start(1000)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
