"""Conservative, frame-based review of camera-start/camera-stop footage.

There is deliberately no phone-gesture classifier here. A large image change at
an outer edge can justify *asking the editor to inspect it*, but cannot justify
deleting a greeting, a reaction, or a hand gesture. Every suggestion is disabled.
No audio measurement is used to infer camera-button operation.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable
import math

import numpy as np

from .engine import Cancelled, Cut, MediaInfo, extract_frame


@dataclass
class EdgeReview:
    start_frames: list[tuple[float, Path]]
    end_frames: list[tuple[float, Path]]
    suggestions: list[Cut]
    explanation: str


def _read_ppm(path: Path) -> np.ndarray:
    """Read FFmpeg's uncompressed P6 thumbnails without an image dependency."""
    raw = path.read_bytes()
    position = 0
    tokens: list[bytes] = []
    while len(tokens) < 4:
        while position < len(raw) and raw[position] in b" \t\r\n":
            position += 1
        if raw[position:position + 1] == b"#":
            position = raw.index(b"\n", position) + 1
            continue
        begin = position
        while position < len(raw) and raw[position] not in b" \t\r\n":
            position += 1
        tokens.append(raw[begin:position])
    if tokens[0] != b"P6" or tokens[3] != b"255":
        raise ValueError("지원하지 않는 미리보기 이미지 형식입니다.")
    # PPM has one separator after maxval; don't strip pixel bytes as whitespace.
    position += 2 if raw[position:position + 2] == b"\r\n" else 1
    width, height = int(tokens[1]), int(tokens[2])
    pixels = np.frombuffer(raw, dtype=np.uint8, count=width * height * 3,
                           offset=position)
    return pixels.reshape(height, width, 3).astype(np.float32) / 255.0


def _edge_candidate(frames: list[tuple[float, Path]], *, leading: bool,
                    duration: float) -> Cut | None:
    """Flag an isolated large change adjacent to an outer edge, never enable it.

    Continuous movement across the window produces no suggestion: it could be
    an introduction or a closing reaction. We require two relatively steady
    transitions after the outer movement before offering a review boundary.
    """
    if len(frames) < 5:
        return None
    ordered = frames if leading else list(reversed(frames))
    images = [_read_ppm(path) for _, path in ordered]
    scores: list[float] = []
    coverage: list[float] = []
    for left, right in zip(images, images[1:]):
        if left.shape != right.shape:
            return None
        delta = np.abs(left - right).mean(axis=2)
        scores.append(float(delta.mean()))
        coverage.append(float((delta > 0.12).mean()))
    baseline = float(np.median(scores))
    threshold = max(0.075, baseline * 2.5)
    active = [score > threshold and area > 0.25
              for score, area in zip(scores, coverage)]
    if not active[0]:
        return None
    last_active = 0
    stable_count = 0
    for index, is_active in enumerate(active):
        if is_active:
            last_active = index
            stable_count = 0
        else:
            stable_count += 1
            if stable_count >= 2:
                break
    if stable_count < 2:
        return None
    boundary = ordered[last_active + 1][0]
    start, end = (0.0, boundary) if leading else (boundary, duration)
    if end - start < 0.15:
        return None
    side = "시작" if leading else "끝"
    return Cut(
        id=f"edge_{'start' if leading else 'end'}",
        start=round(start, 6), end=round(end, 6), kind="edge_review",
        reason=(f"{side} 화면의 큰 변화 · 촬영 버튼 조작 여부는 확인이 필요합니다. "
                "첫인사·표정·마무리 리액션이면 남겨 주세요."),
        enabled=False,
    )


def review_edges(path: str | Path, info: MediaInfo, cache_dir: str | Path,
                 progress: Callable[[float, str], None] | None = None,
                 cancelled: Callable[[], bool] | None = None,
                 window: float = 8.0) -> EdgeReview:
    """Sample real start/end frames and return unchecked visual review hints.

    Thumbnails belong to the caller's cache and may be deleted with it. Times
    are original-video seconds. Both edge windows are always available even
    when no large change is detected; a missing suggestion is not a claim that
    there is no camera operation. ``window`` is clamped to half the duration.
    """
    source = Path(path)
    cache = Path(cache_dir)
    cache.mkdir(parents=True, exist_ok=True)
    duration = float(info.duration)
    if not math.isfinite(duration) or duration <= 0:
        raise ValueError("영상 길이를 확인할 수 없습니다.")
    if not math.isfinite(float(window)) or window <= 0:
        raise ValueError("앞뒤 확인 길이는 0초보다 커야 합니다.")
    edge_length = min(float(window), duration / 2.0)
    frame_margin = min(duration / 4.0, max(0.08, 1.0 / max(1.0, info.fps)))
    last_frame = max(0.0, duration - frame_margin)
    count = max(2, min(9, int(math.ceil(edge_length)) + 1))
    start_times = np.linspace(0.0, min(edge_length, last_frame), count)
    end_times = np.linspace(max(0.0, duration - edge_length), last_frame, count)
    start_frames: list[tuple[float, Path]] = []
    end_frames: list[tuple[float, Path]] = []
    warnings: list[str] = []
    jobs = [("start", float(t), start_frames) for t in start_times]
    jobs += [("end", float(t), end_frames) for t in end_times]
    for index, (side, timestamp, result) in enumerate(jobs):
        if cancelled and cancelled():
            raise Cancelled("앞뒤 화면 확인을 취소했습니다.")
        if progress:
            progress(100.0 * index / len(jobs), "앞뒤 실제 프레임을 확인하고 있습니다.")
        destination = cache / f"edge_{side}_{index:02d}.ppm"
        try:
            extract_frame(source, timestamp, destination, width=192)
            # Read immediately so truncated frames do not break the later UI.
            _read_ppm(destination)
            result.append((timestamp, destination))
        except Cancelled:
            raise
        except Exception:
            warnings.append(f"{timestamp:.1f}초 프레임을 불러오지 못했습니다.")
    if cancelled and cancelled():
        raise Cancelled("앞뒤 화면 확인을 취소했습니다.")
    suggestions: list[Cut] = []
    for frames, leading in ((start_frames, True), (end_frames, False)):
        candidate = _edge_candidate(frames, leading=leading, duration=duration)
        if candidate is not None:
            suggestions.append(candidate)
    explanation = (
        "앞뒤 실제 프레임을 추출했습니다. 화면 변화만으로 촬영 버튼 조작을 "
        "확정할 수 없어 앞뒤 구간은 자동으로 자르지 않습니다. 미리 재생하고 "
        "폰 쪽으로 손을 뻗는 장면인지 확인한 뒤 시작·끝을 직접 조정해 주세요. "
        "첫인사 전 표정과 마지막 리액션은 남겨 주세요."
    )
    if warnings:
        explanation += f" 일부 프레임({len(warnings)}개)을 읽지 못했습니다. 원본 재생으로 확인해 주세요."
    if progress:
        progress(100.0, "앞뒤 프레임 확인 완료 · 자동 삭제 없음")
    return EdgeReview(start_frames, end_frames, suggestions, explanation)
