"""용심리 AutoCut — local first-pass editing."""

__version__ = "1.0.0"
