# Third-party software

This source distribution does not contain third-party binary libraries. The
installer downloads unmodified packages from PyPI.

- Python: PSF license, <https://www.python.org/psf/license/>
- PySide6 / Qt: LGPLv3 / GPLv3 / commercial options; this app uses the open-source,
  dynamically loaded PySide6 distribution. <https://doc.qt.io/qtforpython-6/licenses.html>
- NumPy: BSD-3-Clause. <https://numpy.org/doc/stable/license.html>
- imageio-ffmpeg: BSD-2-Clause wrapper. Its included FFmpeg binary has its own
  licensing, configuration, and source links. <https://github.com/imageio/imageio-ffmpeg>
- FFmpeg: LGPL/GPL depending on build; x264-enabled builds include GPL components.
  <https://ffmpeg.org/legal.html>, <https://www.gyan.dev/ffmpeg/builds/>,
  <https://github.com/BtbN/FFmpeg-Builds>
- PyInstaller (optional build tool): GPL with bootloader exception.
  <https://pyinstaller.org/en/stable/license.html>

For redistribution of a built executable folder, retain the licenses shipped
with all included libraries and the notices/source information applicable to
the exact FFmpeg build. The Windows EXE folder has not been built in this Linux
verification environment.
