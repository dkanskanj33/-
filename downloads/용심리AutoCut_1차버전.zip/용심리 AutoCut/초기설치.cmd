@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo 용심리 AutoCut 초기 설치를 시작합니다.
echo 처음 한 번 인터넷 연결이 필요합니다.
if exist ".venv\Scripts\python.exe" goto install
py -3.12 -m venv .venv 2>nul
if not errorlevel 1 goto install
py -3.13 -m venv .venv 2>nul
if not errorlevel 1 goto install
py -3 -c "import sys; sys.exit(0 if (3,10) <= sys.version_info[:2] < (3,14) else 1)" 2>nul
if errorlevel 1 goto try_python
py -3 -m venv .venv
if not errorlevel 1 goto install
:try_python
python -c "import sys; sys.exit(0 if (3,10) <= sys.version_info[:2] < (3,14) else 1)" 2>nul
if errorlevel 1 goto no_python
python -m venv .venv
if errorlevel 1 goto failed
:install
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install --only-binary=:all: -r requirements.txt
if errorlevel 1 goto failed
.venv\Scripts\python.exe -c "import PySide6.QtWidgets, numpy, imageio_ffmpeg, subprocess; subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(), '-version'], check=True, stdout=subprocess.DEVNULL)"
if errorlevel 1 goto failed
echo.
echo 설치 완료! 이제 [용심리 AutoCut.cmd]를 더블클릭하세요.
pause
exit /b 0
:no_python
echo.
echo Python 3.12 또는 3.13 64비트를 먼저 설치하세요.
echo https://www.python.org/downloads/windows/
echo 설치 화면에서 Add python.exe to PATH를 체크하세요.
pause
exit /b 1
:failed
echo.
echo 설치를 완료하지 못했습니다. 위 오류 내용을 확인하세요.
echo 자세한 설명은 시작_여기부터.md를 열어 보세요.
pause
exit /b 1
