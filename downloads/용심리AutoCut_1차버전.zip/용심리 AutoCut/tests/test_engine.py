"""Local integration checks; requires FFmpeg with libflite for the fixture.

Run from the project root: python -m unittest discover -s tests -v
The flite source is solely a reproducible test fixture; AutoCut never needs a
transcript or an external speech service.
"""
from __future__ import annotations

import hashlib
import json
import os
from fractions import Fraction
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

import numpy as np

from make_sample import make_sample
from yongsimri_autocut.engine import (
    Analysis, Cancelled, Cut, MediaError, Settings, analyze, export_video,
    probe, retained_intervals,
)


def process(args):
    return subprocess.run([str(a) for a in args], check=True, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE)


def checksum(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def decode_audio(path):
    data = process(["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", path,
                    "-map", "0:a:0", "-ac", "1", "-ar", "48000", "-f", "f32le", "-"]).stdout
    return np.frombuffer(data, dtype="<f4")


class TimelineUnitTests(unittest.TestCase):
    def test_disabled_cuts_preserve_everything(self):
        self.assertEqual(retained_intervals(10, [Cut("a", 2, 8, enabled=False)]), [(0.0, 10.0)])

    def test_overlap_is_removed_once(self):
        self.assertEqual(retained_intervals(10, [Cut("a", 2, 5), Cut("b", 4, 7)]),
                         [(0.0, 2.0), (7.0, 10.0)])

    def test_edge_cuts_leave_middle(self):
        self.assertEqual(retained_intervals(10, [Cut("a", 0, 1), Cut("b", 9, 10)]),
                         [(1.0, 9.0)])

    def test_fractional_final_frame_does_not_survive_a_tail_cut(self):
        kept = retained_intervals(20.433333, [Cut("tail", 19, 20.433333)], fps=30)
        self.assertEqual(kept, [(0.0, 19.0)])

    def test_invalid_settings_are_rejected(self):
        # Validation may occur at settings construction or at analyze entry.
        with self.assertRaises((ValueError, MediaError)):
            invalid = Settings(min_silence=0.5, keep_silence=1.0)
            analyze(Path("missing.mp4"), invalid)


class LocalSampleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        configured = os.environ.get("AUTOCUT_SAMPLE_DIR")
        cls._tmp = None
        if configured:
            cls.directory = Path(configured)
        else:
            cls._tmp = tempfile.TemporaryDirectory(prefix="autocut-test-")
            cls.directory = Path(cls._tmp.name) / "한글 경로 샘플"
        cls.source = cls.directory / "반복 대사와 긴 무음 샘플.mp4"
        manifest_path = cls.directory / "sample_manifest.json"
        if not cls.source.exists():
            try:
                cls.source, cls.manifest = make_sample(cls.directory)
            except (FileNotFoundError, subprocess.CalledProcessError) as exc:
                raise unittest.SkipTest("Sample generation requires system FFmpeg with libflite: " + str(exc))
        else:
            cls.manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        cls.source_hash = checksum(cls.source)
        cls.analysis = analyze(cls.source, Settings())
        cls.export_dir = cls.directory / "검증 결과"
        cls.export_dir.mkdir(exist_ok=True)
        cls.output, cls.map_path = export_video(cls.source, cls.analysis.cuts, cls.export_dir,
                                               settings=Settings())
        cls.timemap = json.loads(Path(cls.map_path).read_text(encoding="utf-8"))
        cls.keep = [(s["source_start"], s["source_end"]) for s in cls.timemap["segments"]]

    @classmethod
    def tearDownClass(cls):
        if cls._tmp:
            cls._tmp.cleanup()

    def test_only_interior_long_silence_is_cut(self):
        cuts = [c for c in self.analysis.cuts if c.enabled]
        self.assertEqual(len(cuts), 1, repr(cuts))
        cut = cuts[0]
        self.assertGreater(cut.start, 5.85 + 0.3)
        self.assertLess(cut.end, 9.85 - 0.3)
        self.assertAlmostEqual(cut.end - cut.start, 3.0, delta=0.2)
        self.assertAlmostEqual((cut.start + cut.end) / 2, 7.85, delta=0.1)

    def test_short_pause_repeated_phrases_quiet_voice_breath_and_edges_remain(self):
        enabled = [c for c in self.analysis.cuts if c.enabled]
        protected = [event for event in self.manifest["events"]
                     if not event["label"].startswith("long silence")]
        for event in protected:
            # Exclude .15 sec fixture padding at shared silent boundaries.
            start, end = event["start"] + 0.15, event["end"] - 0.15
            for cut in enabled:
                self.assertFalse(max(start, cut.start) < min(end, cut.end),
                                 f"Cut touched preserved {event['label']}: {cut}")

    def test_output_is_decodable_h264_aac_with_both_streams(self):
        metadata = json.loads(process(["ffprobe", "-v", "error", "-show_streams", "-show_format",
                                       "-of", "json", self.output]).stdout)
        streams = metadata["streams"]
        self.assertTrue(any(s["codec_type"] == "video" and s["codec_name"] == "h264" for s in streams))
        self.assertTrue(any(s["codec_type"] == "audio" and s["codec_name"] == "aac" for s in streams))
        video_stream = next(s for s in streams if s["codec_type"] == "video")
        self.assertAlmostEqual(float(Fraction(video_stream["avg_frame_rate"])), self.analysis.info.fps,
                               delta=0.01)
        decoded = process(["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", self.output,
                           "-map", "0:v:0", "-map", "0:a:0", "-f", "null", "-"])
        self.assertEqual(decoded.stderr, b"")
        expected = sum(end - start for start, end in self.keep)
        self.assertAlmostEqual(float(metadata["format"]["duration"]), expected, delta=0.1)

    def test_source_untouched_and_no_overwrite(self):
        before_video = checksum(self.output)
        before_map = checksum(self.map_path)
        second_video, second_map = export_video(self.source, self.analysis.cuts, self.export_dir,
                                                settings=Settings())
        self.assertNotEqual(Path(second_video), Path(self.output))
        self.assertNotEqual(Path(second_map), Path(self.map_path))
        self.assertEqual(checksum(self.output), before_video)
        self.assertEqual(checksum(self.map_path), before_map)
        self.assertEqual(checksum(self.source), self.source_hash)

    def test_cancel_analysis_and_export_leave_no_outputs(self):
        with self.assertRaises(Cancelled):
            analyze(self.source, Settings(), cancelled=lambda: True)
        destination = self.directory / "취소 저장"
        destination.mkdir(exist_ok=True)
        previous = {p.name for p in destination.iterdir()}
        with self.assertRaises(Cancelled):
            export_video(self.source, self.analysis.cuts, destination, cancelled=lambda: True)
        self.assertEqual({p.name for p in destination.iterdir()}, previous)

    def test_one_channel_speech_is_not_averaged_into_silence(self):
        right_only = self.directory / "오른쪽 채널만 목소리.mp4"
        process(["ffmpeg", "-v", "error", "-y", "-i", self.source, "-map", "0:v:0",
                 "-map", "0:a:0", "-c:v", "copy", "-af", "pan=stereo|c0=0*c0|c1=c1",
                 "-c:a", "aac", "-b:a", "192k", right_only])
        result = analyze(right_only, Settings())
        enabled = [c for c in result.cuts if c.enabled]
        self.assertEqual(len(enabled), 1, repr(enabled))
        self.assertAlmostEqual(enabled[0].start, [c for c in self.analysis.cuts if c.enabled][0].start,
                               delta=0.1)

    def test_bundled_ffmpeg_works_without_ffprobe_on_path(self):
        import imageio_ffmpeg
        bundled = imageio_ffmpeg.get_ffmpeg_exe()
        empty_path = self.directory / "empty PATH"
        empty_path.mkdir(exist_ok=True)
        # Absolute FFmpeg path imitates the Windows pip-installed bundle;
        # neither ffmpeg nor ffprobe is discoverable through PATH here.
        with mock.patch.dict(os.environ, {"PATH": str(empty_path), "IMAGEIO_FFMPEG_EXE": bundled}):
            info = probe(self.source)
            self.assertTrue(info.has_audio)
            self.assertAlmostEqual(info.duration, self.analysis.info.duration, delta=0.1)
            result = analyze(self.source, Settings())
            self.assertEqual(len([c for c in result.cuts if c.enabled]), 1)

    def test_timemap_covers_the_kept_timeline_contiguously(self):
        segments = self.timemap["segments"]
        self.assertEqual(self.timemap["schema_version"], 1)
        self.assertEqual(self.timemap["time_unit"], "seconds")
        cursor = 0.0
        previous_source_end = 0.0
        for segment in segments:
            self.assertAlmostEqual(segment["output_start"], cursor, places=7)
            self.assertGreaterEqual(segment["source_start"], previous_source_end)
            self.assertGreater(segment["source_end"], segment["source_start"])
            self.assertEqual(segment["speed"], 1.0)
            self.assertAlmostEqual(segment["source_end"] - segment["source_start"],
                                   segment["output_end"] - segment["output_start"], places=7)
            cursor = segment["output_end"]
            previous_source_end = segment["source_end"]
        self.assertAlmostEqual(cursor, self.timemap["output"]["duration"], places=7)
        self.assertEqual(self.timemap["source"]["filename"], self.source.name)

    def test_invalid_cut_and_all_removed_are_rejected(self):
        destination = self.directory / "잘못된 컷 저장"
        destination.mkdir(exist_ok=True)
        previous = {p.name for p in destination.iterdir()}
        with self.assertRaises(MediaError):
            export_video(self.source, [Cut("nan", float("nan"), 8)], destination)
        with self.assertRaises(MediaError):
            export_video(self.source, [Cut("all", 0, 1000)], destination)
        self.assertEqual({p.name for p in destination.iterdir()}, previous)

    def test_no_audio_is_reported_and_export_refuses_safely(self):
        silent_video = self.directory / "음성 트랙 없는 원본.mp4"
        process(["ffmpeg", "-v", "error", "-y", "-i", self.source,
                 "-t", "2", "-map", "0:v:0", "-c:v", "copy", "-an", silent_video])
        result = analyze(silent_video, Settings())
        self.assertFalse(result.info.has_audio)
        self.assertEqual(result.cuts, [])
        self.assertTrue(result.warnings)
        with self.assertRaises(MediaError):
            export_video(silent_video, [], self.directory / "음성 없음 저장")

    def test_running_export_can_be_cancelled_and_cleans_staging(self):
        destination = self.directory / "도중 취소 저장"
        destination.mkdir(exist_ok=True)
        previous = {p.name for p in destination.iterdir()}
        state = {"cancel": False}

        def progress(percent, message):
            if percent > 0:
                state["cancel"] = True

        with self.assertRaises(Cancelled):
            export_video(self.source, self.analysis.cuts, destination, progress=progress,
                         cancelled=lambda: state["cancel"])
        self.assertTrue(state["cancel"])
        self.assertEqual({p.name for p in destination.iterdir()}, previous)

    def test_repetition_audio_corresponds_to_source(self):
        # Compare the actual decoded output against the decoded source under
        # each retained interval. Re-encoding allows a small codec difference.
        original, output = decode_audio(self.source), decode_audio(self.output)
        output_cursor = 0
        for start, end in self.keep:
            length = round((end - start) * 48000)
            reference = original[round(start * 48000):round(start * 48000) + length]
            actual = output[output_cursor:output_cursor + length]
            length = min(len(reference), len(actual))
            # Ignore 50 ms at splice/codec boundaries.
            reference, actual = reference[2400:length - 2400], actual[2400:length - 2400]
            self.assertGreater(float(np.corrcoef(reference, actual)[0, 1]), 0.98)
            output_cursor += round((end - start) * 48000)

    def test_many_cuts_join_without_audio_drift(self):
        cuts = [Cut(f"manual-{i}", 0.5 + i * 0.5, 0.7 + i * 0.5) for i in range(30)]
        output, mapping = export_video(self.source, cuts, self.directory / "여러 구간 연결")
        payload = json.loads(Path(mapping).read_text(encoding="utf-8"))
        self.assertEqual(len(payload["segments"]), 31)
        original, decoded = decode_audio(self.source), decode_audio(output)
        correlations = []
        for seg in payload["segments"]:
            x, y = round(seg["source_start"] * 48000), round(seg["output_start"] * 48000)
            length = round((seg["source_end"] - seg["source_start"]) * 48000)
            end = min(length - 960, len(decoded) - y)
            reference, actual = original[x + 960:x + end], decoded[y + 960:y + end]
            if np.sqrt(np.mean(reference ** 2)) > 0.001:
                corr = float(np.corrcoef(reference, actual)[0, 1])
                correlations.append(corr)
                self.assertGreater(corr, 0.97, repr(seg))
        self.assertGreaterEqual(len(correlations), 10)


if __name__ == "__main__":
    unittest.main(verbosity=2)
