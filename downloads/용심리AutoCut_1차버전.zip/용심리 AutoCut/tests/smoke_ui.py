"""Meaningful local desktop-flow smoke test; Windows / Vrew are not simulated.

From the project directory:
    python tests/smoke_ui.py --sample path/to/sample.mp4 --screenshots output_dir
Without --sample, generates the synthetic integration fixture with system FFmpeg.
Linux without DISPLAY uses Qt's offscreen platform and actual CPU-decoded frames.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile
import time

if sys.platform.startswith("linux") and not os.environ.get("DISPLAY"):
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QFileDialog, QMessageBox

from yongsimri_autocut.app import AutoCutWindow, CpuVideoPreview


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample", type=Path)
    parser.add_argument("--screenshots", type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="autocut-ui-test-") as temporary:
        directory = Path(temporary)
        sample = args.sample
        if sample is None:
            from make_sample import make_sample
            sample, _ = make_sample(directory / "한글 경로 샘플")
        app = QApplication([])
        app.setApplicationName("용심리 AutoCut UI 검증")
        window = AutoCutWindow()
        window.show()
        errors, messages, frames = [], [], []
        QMessageBox.warning = lambda *items: errors.append(items[-1])
        QMessageBox.information = lambda *items: messages.append(items[-1])

        def wait_worker(timeout=90):
            deadline = time.monotonic() + timeout
            while window.worker and time.monotonic() < deadline:
                QTest.qWait(30)
            assert not window.worker, "백그라운드 작업 시간 초과"
            assert not errors, errors

        try:
            window.open_file(sample)
            wait_worker()
            assert window.info and window.analyze_btn.isEnabled()
            window.video.videoSink().videoFrameChanged.connect(
                lambda frame: frames.append(frame.isValid()))
            window.player.play()
            QTest.qWait(900)
            window.player.pause()
            assert any(frames), "실제 원본에서 영상 프레임을 디코딩하지 못했습니다."
            if isinstance(window.video, CpuVideoPreview):
                assert window.video._image is not None and not window.video._image.isNull()
            window.start_analysis()
            wait_worker()
            assert window.analysis and window.table.rowCount() > 0
            row = next(i for i, cut in enumerate(window.cuts) if cut.kind == "silence")
            window.table.item(row, 0).setCheckState(Qt.Unchecked)
            assert not window.cuts[row].enabled
            window.table.item(row, 0).setCheckState(Qt.Checked)
            assert window.cuts[row].enabled
            assert all(not c.enabled for c in window.cuts if c.kind == "edge_review")
            window.start_time.setValue(.2)
            window.trim_start.setChecked(True)
            assert any(c.id == "manual-start" for c in window.selected_cuts())
            window.trim_start.setChecked(False)
            window.min_silence.setValue(2.6)
            assert not window.save_btn.isEnabled(), "바뀐 설정으로 이전 분석을 저장하면 안 됩니다."
            window.min_silence.setValue(2.5)
            window.start_analysis()
            wait_worker()
            assert window.save_btn.isEnabled()
            window.table.selectRow(row)
            QTest.qWait(500)
            if args.screenshots:
                args.screenshots.mkdir(parents=True, exist_ok=True)
                window.grab().save(str(args.screenshots / "용심리AutoCut_자를구간확인.png"))
                window.tabs.setCurrentIndex(1)
                QTest.qWait(200)
                window.grab().save(str(args.screenshots / "용심리AutoCut_앞뒤화면.png"))
            output_dir = directory / "한글 저장 폴더"
            output_dir.mkdir()
            QFileDialog.getExistingDirectory = lambda *items: str(output_dir)
            window.start_export()
            wait_worker()
            assert window.last_output and window.last_output.exists()
            mapping = next(output_dir.glob("*_타임맵.json"))
            payload = json.loads(mapping.read_text(encoding="utf-8"))
            assert payload["segments"] and payload["output"]["video_codec"] == "h264"
            assert payload["output"]["audio_codec"] == "aac"
            assert messages and "Vrew" in messages[-1]
            print(json.dumps({"ui_smoke": "PASS", "decoded_preview_frames": sum(frames),
                              "cuts_found": len(window.cuts), "mp4": window.last_output.name,
                              "timemap": mapping.name,
                              "platform": QApplication.platformName(),
                              "windows_vrew_tested": False}, ensure_ascii=False, indent=2))
        finally:
            if window.worker:
                window.cancel_work()
                wait_worker()
            window.close()
            app.processEvents()


if __name__ == "__main__":
    main()
