"""Reproducible local A/V test fixture. No downloads, APIs, or transcript input.

FFmpeg's optional libflite filter creates English synthetic speech. This is a
test fixture, not a recording of a real person or a phone-operation scene.
"""
from __future__ import annotations

import json
from pathlib import Path
import subprocess
import wave

import numpy as np


def run(args):
    return subprocess.run([str(a) for a in args], check=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def make_sample(destination: Path) -> tuple[Path, dict]:
    destination.mkdir(parents=True, exist_ok=True)
    sr = 48000
    phrase_file = destination / "phrase.wav"
    run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi",
         "-i", "flite=text='I will say this sentence twice.':voice=slt",
         "-ar", sr, "-ac", 1, "-c:a", "pcm_s16le", phrase_file])
    with wave.open(str(phrase_file), "rb") as handle:
        phrase = np.frombuffer(handle.readframes(handle.getnframes()), "<i2").astype(np.float64) / 32768
    # Trim only synthetic voice fixture padding; the program receives the MP4.
    active = np.flatnonzero(np.abs(phrase) > 0.0005)
    phrase = phrase[max(0, active[0] - 2400):active[-1] + 2400]
    phrase *= 0.65 / np.max(np.abs(phrase))
    parts, events = [], []
    position = 0

    def append(label, data):
        nonlocal position
        start = position / sr
        parts.append(data)
        position += len(data)
        events.append({"label": label, "start": start, "end": position / sr})

    append("leading expression / no phone footage", np.zeros(round(0.8 * sr)))
    append("spoken phrase A", phrase)
    append("short pause 0.8 seconds", np.zeros(round(0.8 * sr)))
    append("spoken phrase A repeated verbatim", phrase.copy())
    append("long silence 4 seconds", np.zeros(round(4.0 * sr)))
    append("spoken phrase A third time", phrase.copy())
    # Quiet speech, including transient consonants, remains meaningful activity.
    append("quiet synthesized voice", phrase * (0.012 / 0.65))
    rng = np.random.default_rng(20261116)
    breath = rng.normal(0, 1, round(3.0 * sr))
    breath = np.convolve(breath, np.ones(7) / 7, mode="same")
    breath *= 0.006 / np.sqrt(np.mean(breath ** 2))
    envelope = np.sin(np.linspace(0, np.pi, len(breath))) ** 0.5
    append("quiet breath-like generated noise", breath * envelope)
    append("spoken closing phrase", phrase.copy())
    append("trailing reaction / no phone footage", np.zeros(round(1.2 * sr)))
    audio = np.concatenate(parts)
    stereo = np.column_stack((audio, audio * 0.9))
    wav = destination / "샘플 원본 음성.wav"
    with wave.open(str(wav), "wb") as handle:
        handle.setnchannels(2)
        handle.setsampwidth(2)
        handle.setframerate(sr)
        handle.writeframes(np.clip(stereo * 32767, -32768, 32767).astype("<i2").tobytes())
    filters = ["drawtext=text='LOCAL SYNTHETIC TEST - NO PHONE FOOTAGE':x=20:y=20:fontsize=22:fontcolor=white:box=1:boxcolor=black@0.65"]
    for item in events:
        filters.append("drawtext=text='%s':x=20:y=h-60:fontsize=20:fontcolor=white:box=1:boxcolor=black@0.7:enable='between(t,%.6f,%.6f)'" % (item["label"], item["start"], item["end"]))
    video = destination / "반복 대사와 긴 무음 샘플.mp4"
    run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi",
         "-i", "testsrc2=size=640x360:rate=30", "-i", wav,
         "-vf", ",".join(filters), "-t", position / sr,
         "-c:v", "libx264", "-preset", "ultrafast", "-crf", "24", "-pix_fmt", "yuv420p",
         "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", video])
    manifest = {
        "kind": "local English synthetic speech and deterministic test-pattern video",
        "contains_real_phone_operation": False,
        "sample_rate": sr,
        "duration": position / sr,
        "events": events,
        "expected_long_silence": next(e for e in events if e["label"].startswith("long silence")),
        "expected_repeat_count": 5,
        "quiet_voice_peak_dbfs": float(20 * np.log10(0.012)),
    }
    (destination / "sample_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return video, manifest


if __name__ == "__main__":
    import sys
    path, _ = make_sample(Path(sys.argv[1]) if len(sys.argv) > 1 else Path("work/validation/한글 경로 샘플"))
    print(path)
