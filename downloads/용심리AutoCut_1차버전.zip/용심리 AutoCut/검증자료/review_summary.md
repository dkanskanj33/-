# Additional synthetic checks

- Current single-interval CFR export:26cuts/27retained intervals, nonzero container start4.978s; all decoded retained-audio correlations>0.9999998.
- Current VFR export:27cuts/28retained intervals, source average3750/299fps. Output duration16.492s. Audio sample rounding produced0ms first,0.0833ms middle,0.1667ms last lag; all lag-aligned correlations>0.9999998. This is far within the advertised79.733ms frame precision.
- Actual90degree display-matrix rotation: ffprobe probe, FFmpeg-only fallback probe and exported dimensions all120x160. Source/output duration20s, H264/AAC.
- Samples use synthetic test patterns and chirp audio. These checks do not establish actual handset-gesture recognition, real phone compatibility, Windows or Vrew behavior.

Evidence:review_evidence.json, vfr_rotation_evidence.json, vfr_lag_evidence.json, rotation_evidence.json.
